// Servo8Bit Example code
// Ilya Brutman
// Modified for RapidchangeATC servo control by Rocco, Greilick and Logan with AI code generation by Trader

#include <Arduino.h>

#include <EEPROM.h>

#include "Servo8Bit.h"

Servo8Bit leftServo, rightServo; // Create servo objects.

byte rightMotorPin = 1;
byte leftMotorPin = 0;
byte motorControlPin = 2;
byte buttonPin = 3; // Existing override pin

unsigned long LONG_PRESS_DURATION = 5000; // 5 seconds
unsigned long DEBOUNCE_DELAY = 50; // 50 milliseconds

bool isOpen = false;
bool toggle;
bool toggleOverride;
bool isToggleOverride = false;

// EEPROM address for invertCover
#define EEPROM_INVERT_COVER_ADDR  0

// Invert cover flag
bool invertCover = false;

// Existing constants
byte maxAngle = 180;
byte minAngle = 0;
byte motorSpeedDelay = 20;

void openDustCover() {
    leftServo.attach(leftMotorPin);
    rightServo.attach(rightMotorPin);
    // Prevent the servo from going to center on attach
    leftServo.write(minAngle);
    rightServo.write(maxAngle);
    delay(motorSpeedDelay);

    for (int x = maxAngle; x >= minAngle; x -= 10) {
        leftServo.write(maxAngle - x);
        rightServo.write(x);
        delay(motorSpeedDelay);
    }
 
    isOpen = true;
    leftServo.detach();
    rightServo.detach();
}

void closeDustCover() {
    leftServo.attach(leftMotorPin);
    rightServo.attach(rightMotorPin);
    // Prevent the servo from going to center on attach
    leftServo.write(maxAngle);
    rightServo.write(minAngle);
    delay(motorSpeedDelay);

    for (int x = minAngle; x <= maxAngle; x += 10) {
        leftServo.write(maxAngle - x);
        rightServo.write(x);
        delay(motorSpeedDelay);
    }
 
    isOpen = false;
    leftServo.detach();
    rightServo.detach();
}

void setup() {

    pinMode(motorControlPin, INPUT_PULLUP);
    pinMode(buttonPin, INPUT_PULLUP);
  
   invertCover = EEPROM.read(EEPROM_INVERT_COVER_ADDR);
    
   if(invertCover == 1) {
     rightMotorPin = 0;
     leftMotorPin = 1;
   } 

    leftServo.attach(leftMotorPin);
    rightServo.attach(rightMotorPin);

    leftServo.write(minAngle);    
    rightServo.write(maxAngle); 
    delay(motorSpeedDelay);
 
    leftServo.detach();
    rightServo.detach();

}   
    

void loop() {
    
    toggleOverride = digitalRead(buttonPin);
    if (toggleOverride == LOW) {

        unsigned long currentTime = millis();

        delay(DEBOUNCE_DELAY);

        while (digitalRead(buttonPin) == LOW) {  // Wait for state to change from high to low
        }

        delay(DEBOUNCE_DELAY);

        // Calculate how long the button was pressed
        unsigned long timePressed = millis() - currentTime;

        // If the button was pressed for more then duration, toggle invertCover setting in eeprom and appl
        if (timePressed > LONG_PRESS_DURATION) {
            EEPROM.write(EEPROM_INVERT_COVER_ADDR, invertCover ? 0 : 1);
            invertCover = !invertCover;
            if(invertCover == 1) {
              rightMotorPin = 0;
              leftMotorPin = 1;
            } else {
              rightMotorPin = 1;
              leftMotorPin = 0;
            } 
        } else {
            if (toggleOverride == LOW && isToggleOverride && isOpen) {
                isToggleOverride = false;
                if (digitalRead(motorControlPin) == HIGH ) {
                  closeDustCover();
                }
            } else if (toggleOverride == LOW && !isToggleOverride && !isOpen) {
                isToggleOverride = true;
                openDustCover();
            }
        }
    }

    if (isToggleOverride) {
        return;
    }

    toggle = digitalRead(motorControlPin);

    if (toggle == LOW && !isOpen) {
        openDustCover();
    } else if (toggle == HIGH && isOpen) {
        closeDustCover();
    }
    delay(DEBOUNCE_DELAY);

}



